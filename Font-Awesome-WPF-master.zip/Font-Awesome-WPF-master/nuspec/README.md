HOW-TO
======

1. Download NuGet.exe http://nuget.codeplex.com/releases/view/58939
2. Run pack.bat
3. Run push.bat