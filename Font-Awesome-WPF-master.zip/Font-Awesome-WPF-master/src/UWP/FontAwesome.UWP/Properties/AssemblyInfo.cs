﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("Font Awesome UWP")]
[assembly: AssemblyDescription("UWP components for the iconic font and CSS toolkit Font-Awesome")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("charri")]
[assembly: AssemblyProduct("FontAwesome.UWP")]
[assembly: AssemblyCopyright("Copyright © 2015-2017")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

//      Version: First three numbers is FontAwesome version, the last number specifies code revision
//
[assembly: AssemblyVersion("4.7.0.*")]
[assembly: AssemblyFileVersion("4.7.0.9")]
[assembly: ComVisible(false)]